function validate(){  
var form=document.myform.form.value;    

if (date==null || date==""){  
  alert("date can't be blank");  
  return false;  
}
 
else
{
alert('Form Succesfully Submitted');
return true;
}  
}   